package com.kidsworldtv.app

import android.os.Bundle
import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.DisposableEffect
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Sky = Color(0xFFEAF7FF)
private val Navy = Color(0xFF17324D)
private val Coral = Color(0xFFFF8066)
private val Teal = Color(0xFF39BFA7)
private val Yellow = Color(0xFFFFD45C)

data class Lesson(val title: String, val category: String, val age: String, val emoji: String, val description: String, val videoUrl: String = "")

private val lessons = listOf(
    Lesson("Meet the Alphabet: A to Z", "ABC & Reading", "Ages 3–6", "🔤", "Watch, say, and learn the letters from A to Z.", "android.resource://com.kidsworldtv.app/raw/alphabet_lesson"),
    Lesson("Counting from 1 to 10", "Numbers & Maths", "Ages 3–6", "🔢", "Learn to count from one to ten with friendly objects."),
    Lesson("Learn Colours", "Colours & Shapes", "Ages 2–5", "🌈", "Discover red, blue, yellow, green, and purple."),
    Lesson("Amazing Animals", "Nature & Science", "Ages 4–8", "🦁", "Meet animals and learn where they live."),
    Lesson("Our Solar System", "Little Scientists", "Ages 6–9", "🪐", "Take a gentle first trip through space."),
    Lesson("Shapes Hunt", "Colours & Shapes", "Ages 3–6", "🔺", "Find circles, squares, triangles, and more.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KidsWorldApp() }
    }
}

@Composable
fun KidsWorldApp() {
    var selectedCategory by remember { mutableStateOf("All") }
    var search by remember { mutableStateOf("") }
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    var showParentGate by remember { mutableStateOf(false) }
    var parentUnlocked by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("English") }
    var selectedTool by remember { mutableStateOf<String?>(null) }

    val categories = listOf("All", "ABC & Reading", "Numbers & Maths", "Colours & Shapes", "Nature & Science", "Little Scientists")
    val visibleLessons = lessons.filter {
        (selectedCategory == "All" || it.category == selectedCategory) &&
        (it.title.contains(search, ignoreCase = true) || it.category.contains(search, ignoreCase = true))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Teal,
            secondary = Coral,
            background = Sky,
            surface = Color.White,
            onPrimary = Color.White,
            onBackground = Navy,
            onSurface = Navy
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Sky) {
            if (selectedTool != null) {
                LearningToolScreen(tool = selectedTool!!, language = language, onBack = { selectedTool = null })
            } else if (selectedLesson != null) {
                LessonScreen(lesson = selectedLesson!!, onBack = { selectedLesson = null })
            } else if (showParentGate) {
                ParentGate(
                    onCancel = { showParentGate = false },
                    onUnlock = {
                        parentUnlocked = true
                        showParentGate = false
                    }
                )
            } else if (parentUnlocked) {
                ParentScreen(onBack = { parentUnlocked = false })
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 28.dp)
                ) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Navy)
                                .padding(horizontal = 20.dp, vertical = 22.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🌟", fontSize = 30.sp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Kids World TV", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                                    Text("Big fun. Bright minds.", color = Color(0xFFCBEAFF), fontSize = 14.sp)
                                }
                                IconButton(onClick = { showParentGate = true }) {
                                    Icon(Icons.Default.Lock, contentDescription = "Parent area", tint = Color.White)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Image(
                                painter = painterResource(id = R.drawable.kids_world_tv_cover),
                                contentDescription = "Kids World TV cover",
                                modifier = Modifier.fillMaxWidth().height(170.dp),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(Modifier.height(14.dp))
                            Text("Choose language / Khetha ulimi", color = Color.White, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("English", "IsiZulu").forEach { option ->
                                    FilterChip(selected = language == option, onClick = { language = option },
                                        label = { Text(option) }, colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Yellow, selectedLabelColor = Navy, labelColor = Color.White))
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(if (language == "IsiZulu") "Sizofunda ini namuhla?" else "What shall we learn today?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(
                                value = search,
                                onValueChange = { search = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Search lessons") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                )
                            )
                        }
                    }
                    item {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text(if (language == "IsiZulu") "Amathuluzi okufunda" else "More ways to learn", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ToolTile("📖", if (language == "IsiZulu") "Isichazamazwi" else "Dictionary", Modifier.weight(1f)) { selectedTool = "Dictionary" }
                                ToolTile("📚", if (language == "IsiZulu") "Izindaba" else "Story Time", Modifier.weight(1f)) { selectedTool = "Story Time" }
                                ToolTile("🗣️", if (language == "IsiZulu") "Khuluma" else "Speak", Modifier.weight(1f)) { selectedTool = "Speak & Pronounce" }
                            }
                        }
                    }
                    item {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                            Text(if (language == "IsiZulu") "Hlola izihloko" else "Explore topics", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                            Spacer(Modifier.height(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                categories.chunked(2).forEach { pair ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        pair.forEachIndexed { index, category ->
                                            val emoji = when (category) {
                                                "All" -> "✨"
                                                "ABC & Reading" -> "🔤"
                                                "Numbers & Maths" -> "🔢"
                                                "Colours & Shapes" -> "🌈"
                                                "Nature & Science" -> "🐾"
                                                else -> "🚀"
                                            }
                                            val active = selectedCategory == category
                                            Surface(
                                                modifier = Modifier.weight(1f).clickable { selectedCategory = category },
                                                color = if (active) Teal else Color.White,
                                                shape = RoundedCornerShape(14.dp),
                                                shadowElevation = 1.dp
                                            ) {
                                                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(emoji, fontSize = 24.sp)
                                                    Spacer(Modifier.height(4.dp))
                                                    Text(category, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                                        color = if (active) Color.White else Navy)
                                                }
                                            }
                                        }
                                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                            Spacer(Modifier.height(20.dp))
                            Text("Learning videos", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                            Text("Choose a lesson to get started.", fontSize = 14.sp, color = Color(0xFF547087))
                        }
                    }
                    if (visibleLessons.isEmpty()) {
                        item {
                            Text("No lessons found. Try another search.", modifier = Modifier.padding(20.dp), color = Navy)
                        }
                    } else {
                        items(visibleLessons) { lesson ->
                            LessonCard(lesson = lesson, onClick = { selectedLesson = lesson })
                        }
                    }
                    item {
                        Text(
                            "A safe space to learn and grow 💛",
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            color = Color(0xFF547087),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LessonCard(lesson: Lesson, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(76.dp).background(
                    when (lesson.category) {
                        "ABC & Reading" -> Color(0xFFFFE4B8)
                        "Numbers & Maths" -> Color(0xFFD8F5EB)
                        "Colours & Shapes" -> Color(0xFFFFE0E7)
                        "Nature & Science" -> Color(0xFFE0EDFF)
                        else -> Color(0xFFE9E0FF)
                    }, RoundedCornerShape(16.dp)
                ),
                contentAlignment = Alignment.Center
            ) { Text(lesson.emoji, fontSize = 34.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(lesson.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text(lesson.category, fontSize = 13.sp, color = Color(0xFF547087))
                Spacer(Modifier.height(5.dp))
                Text(lesson.age, fontSize = 12.sp, color = Color(0xFF547087))
            }
            Icon(Icons.Default.PlayArrow, contentDescription = "Open lesson", tint = Coral, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
fun LessonScreen(lesson: Lesson, onBack: () -> Unit) {
    val isCounting = lesson.title == "Counting from 1 to 10"
    val isColours = lesson.title == "Learn Colours"
    if (isCounting || isColours) {
        val slides = if (isCounting) listOf(
            Triple("1", "🍎", "ONE apple"), Triple("2", "🐥🐥", "TWO little chicks"),
            Triple("3", "⭐ ⭐ ⭐", "THREE stars"), Triple("4", "🦋 🦋 🦋 🦋", "FOUR butterflies"),
            Triple("5", "🌼 🌼 🌼 🌼 🌼", "FIVE flowers"), Triple("6", "🐠 🐠 🐠 🐠 🐠 🐠", "SIX fish"),
            Triple("7", "🎈 🎈 🎈 🎈 🎈 🎈 🎈", "SEVEN balloons"), Triple("8", "🍓 🍓 🍓 🍓 🍓 🍓 🍓 🍓", "EIGHT strawberries"),
            Triple("9", "🚗 🚗 🚗 🚗 🚗 🚗 🚗 🚗 🚗", "NINE cars"), Triple("10", "🌟 🌟 🌟 🌟 🌟 🌟 🌟 🌟 🌟 🌟", "TEN bright stars")
        ) else listOf(
            Triple("RED", "🍎 ❤️ 🍓", "Red like an apple"),
            Triple("BLUE", "🐳 💙 🫐", "Blue like the ocean"),
            Triple("YELLOW", "☀️ 🌻 ⭐", "Yellow like the sunshine"),
            Triple("GREEN", "🐸 🍀 🥝", "Green like a leaf"),
            Triple("PURPLE", "🍇 💜 🌂", "Purple like grapes")
        )
        var page by remember(lesson.title) { mutableIntStateOf(0) }
        val slide = slides[page]
        val slideColor = if (isCounting) Color(0xFFFFF2CC) else when (slide.first) {
            "RED" -> Color(0xFFFFE0E0)
            "BLUE" -> Color(0xFFDCEEFF)
            "YELLOW" -> Color(0xFFFFF5C2)
            "GREEN" -> Color(0xFFE0F5DF)
            else -> Color(0xFFEEDFFF)
        }
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            TextButton(onClick = onBack, modifier = Modifier.align(Alignment.Start)) { Text("← Back to lessons", color = Navy) }
            Text(lesson.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = slideColor)) {
                Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(slide.first, fontSize = if (isCounting) 76.sp else 46.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                    Spacer(Modifier.height(18.dp))
                    Text(slide.second, fontSize = 35.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Spacer(Modifier.height(18.dp))
                    Text(slide.third, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Slide ${page + 1} of ${slides.size}", color = Navy, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { if (page > 0) page-- }, enabled = page > 0, modifier = Modifier.weight(1f)) { Text("Previous") }
                Button(onClick = { if (page < slides.lastIndex) page++ else page = 0 }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                    Text(if (page == slides.lastIndex) "Start again" else "Next")
                }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            TextButton(onClick = onBack) { Text("← Back to lessons", color = Navy) }
            Spacer(Modifier.height(20.dp))
            if (lesson.videoUrl.isNotBlank()) VideoPlayer(videoUrl = lesson.videoUrl)
            else Box(Modifier.fillMaxWidth().height(220.dp).background(Navy, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(lesson.emoji, fontSize = 64.sp)
                    Spacer(Modifier.height(8.dp))
                    Icon(Icons.Default.PlayArrow, contentDescription = "Video placeholder", tint = Yellow, modifier = Modifier.size(46.dp))
                    Text("VIDEO NOT CONNECTED YET", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text(lesson.title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
            Text(lesson.category + " • " + lesson.age, color = Color(0xFF547087), fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            Text(lesson.description, fontSize = 17.sp, color = Navy)
            Spacer(Modifier.height(20.dp))
            Text(if (lesson.videoUrl.isBlank()) "Video content will be added in a future update." else "If the video does not play, check that the URL is a direct playable video URL and that hosting permits streaming.", color = Color(0xFF547087), fontSize = 14.sp)
        }
    }
}


@Composable
fun ToolTile(emoji: String, title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 25.sp)
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
fun LearningToolScreen(tool: String, language: String, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember { TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS } }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    fun speak(text: String, isiZulu: Boolean = false) {
        if (ttsReady) {
            tts.language = if (isiZulu) Locale("zu", "ZA") else Locale.US
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kwtv_speech")
        }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Back to Kids World TV", color = Navy) }
        Text(tool, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Spacer(Modifier.height(8.dp))
        when (tool) {
            "Dictionary" -> {
                Text("English words with IsiZulu translations", color = Color(0xFF547087))
                Spacer(Modifier.height(12.dp))
                val words = listOf(
                    Triple("Apple", "I-apula", "A fruit / Isithelo"), Triple("Book", "Incwadi", "Something we read / Into esiyifundayo"),
                    Triple("Cat", "Ikati", "A small pet animal / Isilwane esifuywayo"), Triple("Dog", "Inja", "A friendly animal / Isilwane esinobungane"),
                    Triple("Water", "Amanzi", "Something we drink / Esikuphuzayo"), Triple("Sun", "Ilanga", "Bright in the sky / Likhanya esibhakabhakeni"),
                    Triple("House", "Indlu", "A place where we live / Indawo esihlala kuyo"), Triple("School", "Isikole", "A place to learn / Indawo yokufunda")
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(words) { item ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.first, fontWeight = FontWeight.Bold, color = Navy)
                                    Text(item.second, color = Teal, fontWeight = FontWeight.SemiBold)
                                    Text(item.third, color = Color(0xFF547087), fontSize = 12.sp)
                                }
                                IconButton(onClick = { speak(item.first) }) { Icon(Icons.Default.PlayArrow, contentDescription = "Hear word", tint = Coral) }
                            }
                        }
                    }
                }
            }
            "Story Time" -> {
                val storyTitle = if (language == "IsiZulu") "UNala nenyoni encane" else "Nala and the Little Bird"
                val story = if (language == "IsiZulu")
                    "UNala wezwa inyoni encane ikhala esihlahleni. Wayinika amanzi wabiza umama wakhe. Ngokushesha inyoni yazizwa ingcono. UNala wafunda ukuthi ukusiza abanye kubalulekile."
                else "Nala heard a little bird chirping under a tree. The bird was thirsty, so Nala placed a small bowl of water nearby and called her mother. Soon the bird felt better and fluttered happily into the sky. Nala smiled because helping others feels good."
                Text(storyTitle, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Teal)
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Text(story, Modifier.padding(18.dp), fontSize = 18.sp, color = Navy) }
                Spacer(Modifier.height(14.dp))
                Button(onClick = { speak(story, language == "IsiZulu") }, colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null); Text("  Read story aloud")
                }
                Text("Speech depends on the voices installed on your Android phone.", color = Color(0xFF547087), fontSize = 12.sp)
            }
            else -> {
                Text(if (language == "IsiZulu") "Lalela bese uphinda amagama." else "Listen to a word, then say it aloud.", color = Color(0xFF547087))
                Spacer(Modifier.height(14.dp))
                val practice = listOf("Hello" to "Sawubona", "Thank you" to "Ngiyabonga", "Please" to "Ngiyacela", "Friend" to "Umngane", "Good morning" to "Sawubona ekuseni")
                practice.forEach { (english, zulu) ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(english, fontWeight = FontWeight.Bold, color = Navy); Text(zulu, color = Teal) }
                            IconButton(onClick = { speak(if (language == "IsiZulu") zulu else english, language == "IsiZulu") }) { Icon(Icons.Default.PlayArrow, contentDescription = "Pronounce", tint = Coral) }
                        }
                    }
                }
                Text("Tap play to hear pronunciation, then repeat the word with a grown-up.", color = Color(0xFF547087), fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun ParentGate(onCancel: () -> Unit, onUnlock: () -> Unit) {
    var answer by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("🔒 Parent area", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(8.dp))
        Text("For the prototype, answer this simple check: what is 4 + 3?", color = Navy)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = answer, onValueChange = { answer = it }, label = { Text("Answer") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (answer.trim() == "7") onUnlock() }, colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
            Text("Continue")
        }
        TextButton(onClick = onCancel) { Text("Cancel") }
        Text("Prototype only: replace this with a stronger parent verification flow before release.", color = Color(0xFF547087), fontSize = 12.sp)
    }
}

@Composable
fun ParentScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        TextButton(onClick = onBack) { Text("← Back", color = Navy) }
        Text("Parent dashboard", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))
        Text("Content and safety settings", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Navy)
        Spacer(Modifier.height(8.dp))
        Text("• Review lessons before publishing", color = Navy)
        Text("• Add licensed educational videos", color = Navy)
        Text("• Configure privacy and screen-time controls", color = Navy)
        Text("• Integrate only ads suitable for child-directed apps", color = Navy)
        Spacer(Modifier.height(18.dp))
        Text("Advertising is not enabled in this starter build.", color = Color(0xFF547087), fontSize = 14.sp)
    }
}


@Composable
fun VideoPlayer(videoUrl: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUrl))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(220.dp),
        factory = { viewContext: Context ->
            PlayerView(viewContext).apply {
                this.player = player
                useController = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            }
        },
        update = { it.player = player }
    )
}
